import { Controller } from '@nestjs/common';

@Controller('integrations')
export class IntegrationsController {
  // Empty controller for now
}
