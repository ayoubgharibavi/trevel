import { Injectable, Logger } from '@nestjs/common';

export interface MockBookingRequest {
  flightId: string;
  passengers: {
    firstName: string;
    lastName: string;
    gender: 'male' | 'female';
    birthDate: string;
    nationality: string;
  }[];
  contactInfo: {
    email: string;
    phone: string;
  };
  paymentInfo: {
    method: string;
    cardNumber?: string;
    expiryDate?: string;
    cvv?: string;
  };
}

export interface MockBookingResponse {
  success: boolean;
  bookingId: string;
  status: 'CONFIRMED' | 'PENDING' | 'CANCELLED' | 'FAILED';
  totalAmount: number;
  currency: string;
  passengers: {
    firstName: string;
    lastName: string;
    gender: 'male' | 'female';
    birthDate: string;
    nationality: string;
  }[];
  flight: {
    id: string;
    flightNumber: string;
    departure: {
      airportCode: string;
      airportName: string;
      city: string;
      dateTime: string;
    };
    arrival: {
      airportCode: string;
      airportName: string;
      city: string;
      dateTime: string;
    };
  };
  bookingDate: string;
  confirmationCode: string;
  eTicketUrl?: string;
  message?: string;
}

@Injectable()
export class MockBookingService {
  private readonly logger = new Logger(MockBookingService.name);
  private bookings: Map<string, MockBookingResponse> = new Map();

  // Mock flight data
  private mockFlights = {
    'flight-1': {
      id: 'flight-1',
      flightNumber: 'IR123',
      airline: 'ایران ایر',
      departure: {
        airportCode: 'IKA',
        airportName: 'فرودگاه امام خمینی',
        city: 'تهران',
        dateTime: '2024-01-15T08:00:00Z'
      },
      arrival: {
        airportCode: 'MHD',
        airportName: 'فرودگاه شهید هاشمی نژاد',
        city: 'مشهد',
        dateTime: '2024-01-15T09:30:00Z'
      },
      duration: '1h 30m',
      stops: 0,
      price: 1500000,
      taxes: 150000,
      flightClass: 'اقتصادی',
      aircraft: 'Boeing 737',
      availableSeats: 25,
      baggageAllowance: '20 کیلوگرم'
    }
  };

  async bookFlight(flightId: string, bookingData: any): Promise<MockBookingResponse> {
    this.logger.log(`Booking flight ${flightId} with data:`, bookingData);
    
    const bookingId = `booking-${Date.now()}`;
    const mockResponse: MockBookingResponse = {
      success: true,
      bookingId,
      status: 'CONFIRMED',
      totalAmount: 1650000,
      currency: 'IRR',
      passengers: bookingData.passengers || [],
      flight: this.mockFlights[flightId as keyof typeof this.mockFlights] || null,
      bookingDate: new Date().toISOString(),
      confirmationCode: `PNR${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      eTicketUrl: `https://example.com/eticket/${bookingId}`,
      message: 'رزرو با موفقیت انجام شد'
    };

    this.bookings.set(bookingId, mockResponse);
    return mockResponse;
  }

  async getBookingDetails(bookingId: string): Promise<MockBookingResponse | null> {
    return this.bookings.get(bookingId) || null;
  }

  async cancelBooking(bookingId: string): Promise<MockBookingResponse | null> {
    const booking = this.bookings.get(bookingId);
    if (booking) {
      booking.status = 'CANCELLED';
      booking.message = 'رزرو لغو شد';
      this.bookings.set(bookingId, booking);
      return booking;
    }
    return null;
  }

  async getAllBookings(): Promise<MockBookingResponse[]> {
    return Array.from(this.bookings.values());
  }
}