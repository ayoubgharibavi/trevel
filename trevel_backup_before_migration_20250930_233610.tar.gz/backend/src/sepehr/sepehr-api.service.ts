import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { firstValueFrom } from 'rxjs';
import { BadRequestException } from '@nestjs/common';

@Injectable()
export class SepehrApiService {
  private readonly logger = new Logger(SepehrApiService.name);
  private readonly baseUrl: string;
  private readonly apiKey: string;

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
  ) {
    this.baseUrl = this.configService.get<string>('SEPEHR_API_URL', 'https://api.sepehr.com');
    this.apiKey = this.configService.get<string>('SEPEHR_API_KEY', 'demo-key');
  }

  async searchFlights(searchQuery: any): Promise<any> {
    try {
      this.logger.log(`🔍 Searching flights via Sepehr API: ${JSON.stringify(searchQuery)}`);

      // Mock response for demonstration
      const mockFlights = [
        {
          id: 'sepehr-001',
          flightNumber: 'SP-101',
          airline: 'سپهر',
          airlineLogoUrl: 'https://example.com/sepehr-logo.png',
          departureAirport: searchQuery.from,
          arrivalAirport: searchQuery.to,
          departureTime: new Date(searchQuery.departureDate),
          arrivalTime: new Date(new Date(searchQuery.departureDate).getTime() + 2 * 60 * 60 * 1000),
          price: 1500000,
          taxes: 150000,
          currency: 'IRR',
          availableSeats: 45,
          totalCapacity: 180,
          baggageAllowance: '20 کیلوگرم',
          status: 'SCHEDULED',
        },
        {
          id: 'sepehr-002',
          flightNumber: 'SP-102',
          airline: 'سپهر',
          airlineLogoUrl: 'https://example.com/sepehr-logo.png',
          departureAirport: searchQuery.from,
          arrivalAirport: searchQuery.to,
          departureTime: new Date(new Date(searchQuery.departureDate).getTime() + 3 * 60 * 60 * 1000),
          arrivalTime: new Date(new Date(searchQuery.departureDate).getTime() + 5 * 60 * 60 * 1000),
          price: 1800000,
          taxes: 180000,
          currency: 'IRR',
          availableSeats: 32,
          totalCapacity: 180,
          baggageAllowance: '20 کیلوگرم',
          status: 'SCHEDULED',
        },
      ];

      return {
        success: true,
        data: mockFlights,
        total: mockFlights.length,
        message: 'جستجوی پرواز با موفقیت انجام شد',
      };
    } catch (error) {
      this.logger.error(`❌ Sepehr API search failed: ${(error as any).message}`);
      throw new Error('خطا در جستجوی پرواز از طریق سپهر');
    }
  }

  async bookFlight(flightId: string, passengerInfo: any): Promise<any> {
    try {
      this.logger.log(`🔍 Booking flight via Sepehr API: ${flightId}`);

      const bookingPayload = {
        flightId,
        passengers: passengerInfo.passengers,
        contactInfo: passengerInfo.contactInfo,
        paymentMethod: passengerInfo.paymentMethod,
      };

      // Mock booking response
      const mockBooking = {
        bookingId: `SP-${Date.now()}`,
        flightId,
        status: 'CONFIRMED',
        passengers: passengerInfo.passengers,
        totalPrice: 1650000,
        taxes: 165000,
        currency: 'IRR',
        bookingDate: new Date(),
        confirmationCode: `SP${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
        paymentStatus: 'PAID',
        seatNumbers: ['12A', '12B'],
        baggageAllowance: '20 کیلوگرم',
      };

      return {
        success: true,
        data: mockBooking,
        message: 'رزرو با موفقیت انجام شد',
      };
    } catch (error) {
      this.logger.error(`❌ Sepehr API booking failed: ${(error as any).message}`);
      throw new Error('خطا در رزرو پرواز از طریق سپهر');
    }
  }

  async cancelBooking(bookingId: string): Promise<any> {
    try {
      this.logger.log(`🔍 Canceling booking via Sepehr API: ${bookingId}`);

      // Mock cancellation response
      const mockCancellation = {
        bookingId,
        status: 'CANCELLED',
        cancellationDate: new Date(),
        refundAmount: 1485000, // 90% refund
        refundStatus: 'PROCESSING',
        refundMethod: 'ORIGINAL_PAYMENT',
      };

      return {
        success: true,
        data: mockCancellation,
        message: 'لغو رزرو با موفقیت انجام شد',
      };
    } catch (error) {
      this.logger.error(`❌ Sepehr API cancellation failed: ${(error as any).message}`);
      throw new Error('خطا در لغو رزرو از طریق سپهر');
    }
  }

  async getBookingDetails(bookingId: string): Promise<any> {
    try {
      this.logger.log(`🔍 Getting booking details via Sepehr API: ${bookingId}`);

      // Mock booking details
      const mockBookingDetails = {
        bookingId,
        flightId: 'sepehr-001',
        status: 'CONFIRMED',
        passengers: [
          {
            firstName: 'علی',
            lastName: 'احمدی',
            passportNumber: 'A1234567',
            nationality: 'IR',
            gender: 'MALE',
            seatNumber: '12A',
          },
        ],
        totalPrice: 1650000,
        taxes: 165000,
        currency: 'IRR',
        bookingDate: new Date(),
        confirmationCode: 'SP123456',
        paymentStatus: 'PAID',
        seatNumbers: ['12A'],
        baggageAllowance: '20 کیلوگرم',
        flightDetails: {
          flightNumber: 'SP-101',
          airline: 'سپهر',
          departureAirport: 'تهران',
          arrivalAirport: 'مشهد',
          departureTime: new Date(),
          arrivalTime: new Date(Date.now() + 2 * 60 * 60 * 1000),
        },
      };

      return {
        success: true,
        data: mockBookingDetails,
        message: 'جزئیات رزرو با موفقیت دریافت شد',
      };
    } catch (error) {
      this.logger.error(`❌ Sepehr API get booking details failed: ${(error as any).message}`);
      throw new Error('خطا در دریافت جزئیات رزرو از طریق سپهر');
    }
  }

  async checkAvailability(flightId: string): Promise<any> {
    try {
      this.logger.log(`🔍 Checking availability via Sepehr API: ${flightId}`);

      // Mock availability check
      const mockAvailability = {
        flightId,
        availableSeats: 45,
        totalCapacity: 180,
        seatClasses: [
          {
            class: 'ECONOMY',
            availableSeats: 40,
            price: 1500000,
          },
          {
            class: 'BUSINESS',
            availableSeats: 5,
            price: 2500000,
          },
        ],
        lastUpdated: new Date(),
      };

      return {
        success: true,
        data: mockAvailability,
        message: 'بررسی موجودی با موفقیت انجام شد',
      };
    } catch (error) {
      this.logger.error(`❌ Sepehr API availability check failed: ${(error as any).message}`);
      throw new Error('خطا در بررسی موجودی از طریق سپهر');
    }
  }

  async getFlightDetails(flightId: string): Promise<any> {
    try {
      this.logger.log(`🔍 Getting flight details via Sepehr API: ${flightId}`);

      // Mock flight details
      const mockFlightDetails = {
        id: flightId,
        flightNumber: 'SP-101',
        airline: 'سپهر',
        airlineLogoUrl: 'https://example.com/sepehr-logo.png',
        departureAirport: 'تهران',
        arrivalAirport: 'مشهد',
        departureTime: new Date(),
        arrivalTime: new Date(Date.now() + 2 * 60 * 60 * 1000),
        duration: '2 ساعت',
        aircraft: 'Boeing 737',
        price: 1500000,
        taxes: 150000,
        currency: 'IRR',
        availableSeats: 45,
        totalCapacity: 180,
        baggageAllowance: '20 کیلوگرم',
        status: 'SCHEDULED',
        amenities: [
          'غذای رایگان',
          'نوشیدنی رایگان',
          'WiFi رایگان',
          'صندلی راحت',
        ],
      };

      return {
        success: true,
        data: mockFlightDetails,
        message: 'جزئیات پرواز با موفقیت دریافت شد',
      };
    } catch (error) {
      this.logger.error(`❌ Sepehr API get flight details failed: ${(error as any).message}`);
      throw new Error('خطا در دریافت جزئیات پرواز از طریق سپهر');
    }
  }

  async checkConnection(): Promise<boolean> {
    try {
      this.logger.log('🔍 Checking Sepehr API connection...');
      
      // Mock connection check
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      this.logger.log('✅ Sepehr API connection successful');
      return true;
    } catch (error) {
      this.logger.error(`❌ Sepehr API connection check failed: ${(error as any).message}`);
      return false;
    }
  }
}