import { Controller, Get, Post, Put, Delete, Body, Param, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { AdvertisementService } from './advertisement.service';

@ApiTags('advertisements')
@Controller('advertisements')
export class AdvertisementController {
  constructor(private readonly advertisementService: AdvertisementService) {}

  @Get()
  @ApiOperation({ summary: 'Get all advertisements' })
  async getAllAdvertisements() {
    return this.advertisementService.getAllAdvertisements();
  }

  @Post()
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create new advertisement' })
  async createAdvertisement(@Body() createDto: any) {
    return this.advertisementService.createAdvertisement(createDto);
  }

  @Put(':id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update advertisement' })
  async updateAdvertisement(@Param('id') id: string, @Body() updateDto: any) {
    return this.advertisementService.updateAdvertisement(id, updateDto);
  }

  @Delete(':id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Delete advertisement' })
  async deleteAdvertisement(@Param('id') id: string) {
    return this.advertisementService.deleteAdvertisement(id);
  }
}

