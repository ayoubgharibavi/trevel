import { Injectable } from '@nestjs/common';

@Injectable()
export class AdvertisementService {
  async getAllAdvertisements() {
    return [];
  }

  async createAdvertisement(createDto: any) {
    return { id: '1', ...createDto };
  }

  async updateAdvertisement(id: string, updateDto: any) {
    return { id, ...updateDto };
  }

  async deleteAdvertisement(id: string) {
    return { success: true, id };
  }
}

