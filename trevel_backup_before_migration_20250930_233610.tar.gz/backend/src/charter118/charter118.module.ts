import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { Charter118Controller } from './charter118.controller';
import { Charter118Service } from './charter118.service';

@Module({
  imports: [ConfigModule],
  controllers: [Charter118Controller],
  providers: [Charter118Service],
  exports: [Charter118Service],
})
export class Charter118Module {}
