import React, { useState } from 'react';
import { useLocalization } from '@/hooks/useLocalization';
import { UsersIcon } from './icons/UsersIcon';
import { PlusIcon } from './icons/PlusIcon';
import { XIcon } from './icons/XIcon';

interface PassengerCount {
  adults: number;
  children: number;
  infants: number;
}

interface PassengerSelectorProps {
  value: PassengerCount;
  onChange: (passengers: PassengerCount) => void;
  className?: string;
  disabled?: boolean;
}

const PassengerSelector: React.FC<PassengerSelectorProps> = ({
  value,
  onChange,
  className = '',
  disabled = false
}) => {
  const { t } = useLocalization();
  const [isOpen, setIsOpen] = useState(false);

  const updatePassengers = (type: keyof PassengerCount, delta: number) => {
    const newValue = { ...value };
    newValue[type] = Math.max(0, newValue[type] + delta);
    
    // Validation rules
    if (type === 'infants' && newValue.infants > newValue.adults) {
      newValue.infants = newValue.adults;
    }
    
    onChange(newValue);
  };

  const getTotalPassengers = () => {
    return value.adults + value.children + value.infants;
  };

  const getPassengerText = () => {
    const total = getTotalPassengers();
    if (total === 0) return 'مسافر';
    if (total === 1) return '۱ مسافر';
    return `${total} مسافر`;
  };

  const getDetailedText = () => {
    const parts = [];
    if (value.adults > 0) parts.push(`${value.adults} بزرگسال`);
    if (value.children > 0) parts.push(`${value.children} کودک`);
    if (value.infants > 0) parts.push(`${value.infants} نوزاد`);
    return parts.join('، ');
  };

  return (
    <div className={`relative ${className}`}>
      {/* Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        disabled={disabled}
        className={`
          w-full px-4 py-3 border border-gray-300 rounded-lg
          focus:ring-2 focus:ring-blue-500 focus:border-blue-500
          disabled:bg-gray-100 disabled:cursor-not-allowed
          text-right flex items-center justify-between
          hover:border-gray-400 transition-colors
        `}
      >
        <div className="flex items-center space-x-2">
          <UsersIcon className="w-5 h-5 text-gray-600" />
          <div className="text-right">
            <div className="font-medium text-gray-900">{getPassengerText()}</div>
            {getTotalPassengers() > 0 && (
              <div className="text-sm text-gray-500">{getDetailedText()}</div>
            )}
          </div>
        </div>
        <div className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`}>
          <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </button>

      {/* Dropdown */}
      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg">
          <div className="p-4 space-y-4">
            {/* Adults */}
            <div className="flex items-center justify-between">
              <div className="text-right">
                <div className="font-medium text-gray-900">بزرگسال</div>
                <div className="text-sm text-gray-500">۱۲ سال و بالاتر</div>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => updatePassengers('adults', -1)}
                  disabled={value.adults <= 1}
                  className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <XIcon className="w-4 h-4" />
                </button>
                <span className="w-8 text-center font-medium">{value.adults}</span>
                <button
                  type="button"
                  onClick={() => updatePassengers('adults', 1)}
                  disabled={value.adults >= 9}
                  className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <PlusIcon className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Children */}
            <div className="flex items-center justify-between">
              <div className="text-right">
                <div className="font-medium text-gray-900">کودک</div>
                <div className="text-sm text-gray-500">۲ تا ۱۱ سال</div>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => updatePassengers('children', -1)}
                  disabled={value.children <= 0}
                  className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <XIcon className="w-4 h-4" />
                </button>
                <span className="w-8 text-center font-medium">{value.children}</span>
                <button
                  type="button"
                  onClick={() => updatePassengers('children', 1)}
                  disabled={value.children >= 9}
                  className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <PlusIcon className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Infants */}
            <div className="flex items-center justify-between">
              <div className="text-right">
                <div className="font-medium text-gray-900">نوزاد</div>
                <div className="text-sm text-gray-500">زیر ۲ سال</div>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => updatePassengers('infants', -1)}
                  disabled={value.infants <= 0}
                  className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <XIcon className="w-4 h-4" />
                </button>
                <span className="w-8 text-center font-medium">{value.infants}</span>
                <button
                  type="button"
                  onClick={() => updatePassengers('infants', 1)}
                  disabled={value.infants >= value.adults || value.infants >= 9}
                  className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <PlusIcon className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Info */}
            <div className="pt-3 border-t border-gray-200">
              <div className="text-xs text-gray-500 text-center">
                تعداد نوزادان نمی‌تواند از تعداد بزرگسالان بیشتر باشد
              </div>
            </div>

            {/* Done Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
              >
                تایید
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PassengerSelector;

