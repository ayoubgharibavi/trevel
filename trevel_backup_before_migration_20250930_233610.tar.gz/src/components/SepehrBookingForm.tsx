import React, { useState } from 'react';
import { useLocalization } from '@/hooks/useLocalization';
import { apiService } from '@/services/apiService';
import { PlaneIcon } from './icons/PlaneIcon';
import { CalendarIcon } from './icons/CalendarIcon';
import { UsersIcon } from './icons/UsersIcon';
import { MapPinIcon } from './icons/MapPinIcon';

interface SepehrBookingFormProps {
  onSearch?: (searchData: any) => void;
  className?: string;
}

const SepehrBookingForm: React.FC<SepehrBookingFormProps> = ({
  onSearch,
  className = ''
}) => {
  const { t } = useLocalization();
  const [formData, setFormData] = useState({
    from: '',
    to: '',
    departureDate: '',
    returnDate: '',
    passengers: {
      adults: 1,
      children: 0,
      infants: 0
    },
    tripType: 'oneway'
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePassengerChange = (type: string, value: number) => {
    setFormData(prev => ({
      ...prev,
      passengers: {
        ...prev.passengers,
        [type]: Math.max(0, value)
      }
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const searchData = {
        ...formData,
        passengers: formData.passengers.adults + formData.passengers.children + formData.passengers.infants
      };
      
      onSearch?.(searchData);
    } catch (error) {
      console.error('Error searching flights:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getTotalPassengers = () => {
    return formData.passengers.adults + formData.passengers.children + formData.passengers.infants;
  };

  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 p-6 ${className}`}>
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Trip Type */}
        <div className="flex space-x-2">
          <button
            type="button"
            onClick={() => handleInputChange('tripType', 'oneway')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              formData.tripType === 'oneway'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            یک طرفه
          </button>
          <button
            type="button"
            onClick={() => handleInputChange('tripType', 'roundtrip')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              formData.tripType === 'roundtrip'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            رفت و برگشت
          </button>
        </div>

        {/* From and To */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">مبدا</label>
            <div className="relative">
              <MapPinIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={formData.from}
                onChange={(e) => handleInputChange('from', e.target.value)}
                placeholder="شهر یا فرودگاه مبدا"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">مقصد</label>
            <div className="relative">
              <MapPinIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={formData.to}
                onChange={(e) => handleInputChange('to', e.target.value)}
                placeholder="شهر یا فرودگاه مقصد"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
          </div>
        </div>

        {/* Dates */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ رفت</label>
            <div className="relative">
              <CalendarIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="date"
                value={formData.departureDate}
                onChange={(e) => handleInputChange('departureDate', e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
          </div>
          {formData.tripType === 'roundtrip' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ برگشت</label>
              <div className="relative">
                <CalendarIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="date"
                  value={formData.returnDate}
                  onChange={(e) => handleInputChange('returnDate', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          )}
        </div>

        {/* Passengers */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">مسافران</label>
          <div className="relative">
            <UsersIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <div className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg bg-gray-50">
              <div className="flex items-center justify-between">
                <span className="text-gray-700">
                  {getTotalPassengers()} مسافر
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => handlePassengerChange('adults', formData.passengers.adults - 1)}
                    disabled={formData.passengers.adults <= 1}
                    className="w-6 h-6 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50"
                  >
                    -
                  </button>
                  <span className="w-8 text-center">{formData.passengers.adults}</span>
                  <button
                    type="button"
                    onClick={() => handlePassengerChange('adults', formData.passengers.adults + 1)}
                    className="w-6 h-6 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium flex items-center justify-center space-x-2"
        >
          {isLoading ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              <span>در حال جستجو...</span>
            </>
          ) : (
            <>
              <PlaneIcon className="w-5 h-5" />
              <span>جستجوی پرواز</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default SepehrBookingForm;

