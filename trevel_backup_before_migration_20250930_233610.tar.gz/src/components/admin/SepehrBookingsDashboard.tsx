import React, { useState, useEffect } from 'react';
import { useLocalization } from '@/hooks/useLocalization';
import { apiService } from '@/services/apiService';
import { ChartBarIcon } from '../icons/ChartBarIcon';
import { ClipboardListIcon } from '../icons/ClipboardListIcon';

interface DashboardStats {
  totalBookings: number;
  confirmedBookings: number;
  pendingBookings: number;
  cancelledBookings: number;
  totalRevenue: number;
  averageBookingValue: number;
  bookingsByMonth: Array<{
    month: string;
    count: number;
    revenue: number;
  }>;
  topRoutes: Array<{
    route: string;
    count: number;
  }>;
}

const SepehrBookingsDashboard: React.FC = () => {
  const { t } = useLocalization();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('30');

  useEffect(() => {
    fetchDashboardStats();
  }, [selectedPeriod]);

  const fetchDashboardStats = async () => {
    try {
      setIsLoading(true);
      const response = await apiService.get(`/api/v1/sepehr/dashboard-stats?period=${selectedPeriod}`);
      setStats(response);
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      // Mock data for demonstration
      setStats({
        totalBookings: 1250,
        confirmedBookings: 980,
        pendingBookings: 150,
        cancelledBookings: 120,
        totalRevenue: 3125000000,
        averageBookingValue: 2500000,
        bookingsByMonth: [
          { month: 'فروردین', count: 120, revenue: 300000000 },
          { month: 'اردیبهشت', count: 135, revenue: 337500000 },
          { month: 'خرداد', count: 150, revenue: 375000000 },
          { month: 'تیر', count: 180, revenue: 450000000 },
          { month: 'مرداد', count: 200, revenue: 500000000 },
          { month: 'شهریور', count: 175, revenue: 437500000 },
        ],
        topRoutes: [
          { route: 'تهران - مشهد', count: 450 },
          { route: 'مشهد - تهران', count: 380 },
          { route: 'تهران - اصفهان', count: 250 },
          { route: 'اصفهان - تهران', count: 200 },
          { route: 'تهران - شیراز', count: 180 },
        ],
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat('fa-IR').format(amount);
  };

  const getStatusPercentage = (count: number, total: number) => {
    return total > 0 ? Math.round((count / total) * 100) : 0;
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">خطا در بارگذاری آمار</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <ChartBarIcon className="w-8 h-8 text-blue-600" />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">داشبورد رزروهای سپهر</h2>
            <p className="text-gray-600">آمار و گزارش‌های رزروهای انجام شده از طریق سپهر</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <label className="text-sm font-medium text-gray-700">دوره زمانی:</label>
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="7">۷ روز گذشته</option>
            <option value="30">۳۰ روز گذشته</option>
            <option value="90">۹۰ روز گذشته</option>
            <option value="365">سال گذشته</option>
          </select>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <ClipboardListIcon className="w-6 h-6 text-blue-600" />
            </div>
            <div className="mr-3">
              <p className="text-sm font-medium text-gray-600">کل رزروها</p>
              <p className="text-2xl font-bold text-gray-900">{formatPrice(stats.totalBookings)}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <ChartBarIcon className="w-6 h-6 text-green-600" />
            </div>
            <div className="mr-3">
              <p className="text-sm font-medium text-gray-600">رزروهای تأیید شده</p>
              <p className="text-2xl font-bold text-gray-900">{formatPrice(stats.confirmedBookings)}</p>
              <p className="text-xs text-gray-500">{getStatusPercentage(stats.confirmedBookings, stats.totalBookings)}%</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <ChartBarIcon className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="mr-3">
              <p className="text-sm font-medium text-gray-600">در انتظار تأیید</p>
              <p className="text-2xl font-bold text-gray-900">{formatPrice(stats.pendingBookings)}</p>
              <p className="text-xs text-gray-500">{getStatusPercentage(stats.pendingBookings, stats.totalBookings)}%</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-2 bg-red-100 rounded-lg">
              <ChartBarIcon className="w-6 h-6 text-red-600" />
            </div>
            <div className="mr-3">
              <p className="text-sm font-medium text-gray-600">لغو شده</p>
              <p className="text-2xl font-bold text-gray-900">{formatPrice(stats.cancelledBookings)}</p>
              <p className="text-xs text-gray-500">{getStatusPercentage(stats.cancelledBookings, stats.totalBookings)}%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Revenue Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">درآمد کل</h3>
          <div className="flex items-center">
            <div className="p-3 bg-green-100 rounded-lg">
              <ChartBarIcon className="w-8 h-8 text-green-600" />
            </div>
            <div className="mr-4">
              <p className="text-3xl font-bold text-gray-900">{formatPrice(stats.totalRevenue)} تومان</p>
              <p className="text-sm text-gray-600">درآمد کل از رزروها</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">میانگین ارزش رزرو</h3>
          <div className="flex items-center">
            <div className="p-3 bg-blue-100 rounded-lg">
              <ChartBarIcon className="w-8 h-8 text-blue-600" />
            </div>
            <div className="mr-4">
              <p className="text-3xl font-bold text-gray-900">{formatPrice(stats.averageBookingValue)} تومان</p>
              <p className="text-sm text-gray-600">میانگین مبلغ هر رزرو</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Bookings Chart */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">رزروها بر اساس ماه</h3>
          <div className="space-y-3">
            {stats.bookingsByMonth.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-sm text-gray-600">{item.month}</span>
                <div className="flex items-center space-x-3">
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${(item.count / Math.max(...stats.bookingsByMonth.map(m => m.count))) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-medium text-gray-900 w-12 text-left">{item.count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Routes */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">محبوب‌ترین مسیرها</h3>
          <div className="space-y-3">
            {stats.topRoutes.map((route, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-sm text-gray-600">{route.route}</span>
                <div className="flex items-center space-x-3">
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-green-600 h-2 rounded-full"
                      style={{ width: `${(route.count / Math.max(...stats.topRoutes.map(r => r.count))) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-medium text-gray-900 w-12 text-left">{route.count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Status Distribution */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">توزیع وضعیت رزروها</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-green-600 font-bold">{getStatusPercentage(stats.confirmedBookings, stats.totalBookings)}%</span>
            </div>
            <p className="text-sm text-gray-600">تأیید شده</p>
            <p className="text-lg font-semibold text-gray-900">{formatPrice(stats.confirmedBookings)}</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-yellow-600 font-bold">{getStatusPercentage(stats.pendingBookings, stats.totalBookings)}%</span>
            </div>
            <p className="text-sm text-gray-600">در انتظار</p>
            <p className="text-lg font-semibold text-gray-900">{formatPrice(stats.pendingBookings)}</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-red-600 font-bold">{getStatusPercentage(stats.cancelledBookings, stats.totalBookings)}%</span>
            </div>
            <p className="text-sm text-gray-600">لغو شده</p>
            <p className="text-lg font-semibold text-gray-900">{formatPrice(stats.cancelledBookings)}</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-blue-600 font-bold">100%</span>
            </div>
            <p className="text-sm text-gray-600">کل رزروها</p>
            <p className="text-lg font-semibold text-gray-900">{formatPrice(stats.totalBookings)}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SepehrBookingsDashboard;

