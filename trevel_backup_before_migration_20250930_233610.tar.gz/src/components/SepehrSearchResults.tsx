import React, { useState } from 'react';
import { useLocalization } from '@/hooks/useLocalization';
import { apiService } from '@/services/apiService';
import { SearchIcon } from './icons/SearchIcon';
import { PlaneIcon } from './icons/PlaneIcon';

interface SepehrSearchResult {
  id: string;
  flightNumber: string;
  airline: string;
  departure: {
    airport: string;
    city: string;
    time: string;
  };
  arrival: {
    airport: string;
    city: string;
    time: string;
  };
  price: number;
  currency: string;
  duration: string;
  stops: number;
}

interface SepehrSearchResultsProps {
  results: SepehrSearchResult[];
  isLoading?: boolean;
  onSelect?: (result: SepehrSearchResult) => void;
  className?: string;
}

const SepehrSearchResults: React.FC<SepehrSearchResultsProps> = ({
  results,
  isLoading = false,
  onSelect,
  className = ''
}) => {
  const { t } = useLocalization();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fa-IR').format(price);
  };

  const formatTime = (time: string) => {
    return new Date(time).toLocaleTimeString('fa-IR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className={`space-y-4 ${className}`}>
        {[...Array(3)].map((_, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 animate-pulse">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                <div>
                  <div className="h-4 bg-gray-200 rounded w-24 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-16"></div>
                </div>
              </div>
              <div className="h-6 bg-gray-200 rounded w-20"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div className={`text-center py-12 ${className}`}>
        <div className="text-gray-400 mb-4">
          <SearchIcon className="mx-auto h-12 w-12" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">هیچ پروازی یافت نشد</h3>
        <p className="text-gray-500">لطفاً معیارهای جستجو را تغییر دهید</p>
      </div>
    );
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {results.map((result) => (
        <div
          key={result.id}
          className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer"
          onClick={() => onSelect?.(result)}
        >
          <div className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <PlaneIcon className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <div className="font-semibold text-gray-900">{result.airline}</div>
                  <div className="text-sm text-gray-600">{result.flightNumber}</div>
                </div>
              </div>
              <div className="text-left">
                <div className="text-xl font-bold text-blue-600">{formatPrice(result.price)}</div>
                <div className="text-sm text-gray-600">{result.currency}</div>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between">
              <div className="text-center">
                <div className="text-lg font-semibold text-gray-900">{formatTime(result.departure.time)}</div>
                <div className="text-sm text-gray-600">{result.departure.airport}</div>
                <div className="text-xs text-gray-500">{result.departure.city}</div>
              </div>

              <div className="flex-1 mx-4">
                <div className="flex items-center justify-center">
                  <div className="flex-1 h-px bg-gray-300"></div>
                  <div className="mx-2 text-center">
                    <div className="text-xs text-gray-500">{result.duration}</div>
                    <div className="text-xs text-gray-500">
                      {result.stops === 0 ? 'مستقیم' : `${result.stops} توقف`}
                    </div>
                  </div>
                  <div className="flex-1 h-px bg-gray-300"></div>
                </div>
              </div>

              <div className="text-center">
                <div className="text-lg font-semibold text-gray-900">{formatTime(result.arrival.time)}</div>
                <div className="text-sm text-gray-600">{result.arrival.airport}</div>
                <div className="text-xs text-gray-500">{result.arrival.city}</div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SepehrSearchResults;

