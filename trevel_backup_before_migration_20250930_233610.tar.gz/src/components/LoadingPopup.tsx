import React from 'react';
import { useLocalization } from '@/hooks/useLocalization';

interface LoadingPopupProps {
  isVisible: boolean;
  message?: string;
  title?: string;
  showProgress?: boolean;
  progress?: number;
  onCancel?: () => void;
  showCancelButton?: boolean;
}

const LoadingPopup: React.FC<LoadingPopupProps> = ({
  isVisible,
  message = 'در حال بارگذاری...',
  title = 'لطفاً صبر کنید',
  showProgress = false,
  progress = 0,
  onCancel,
  showCancelButton = false
}) => {
  const { t } = useLocalization();

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4 shadow-xl">
        {/* Header */}
        <div className="text-center mb-4">
          <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        </div>

        {/* Loading Animation */}
        <div className="flex justify-center mb-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>

        {/* Message */}
        <div className="text-center mb-4">
          <p className="text-gray-600">{message}</p>
        </div>

        {/* Progress Bar */}
        {showProgress && (
          <div className="mb-4">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
              ></div>
            </div>
            <div className="text-center mt-2 text-sm text-gray-600">
              {Math.round(progress)}%
            </div>
          </div>
        )}

        {/* Cancel Button */}
        {showCancelButton && onCancel && (
          <div className="text-center">
            <button
              onClick={onCancel}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
            >
              انصراف
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoadingPopup;

