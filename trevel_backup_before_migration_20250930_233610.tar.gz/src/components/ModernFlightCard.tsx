import React from 'react';
import { useLocalization } from '@/hooks/useLocalization';
import { PlaneIcon } from './icons/PlaneIcon';
import { ClockIcon } from './icons/ClockIcon';
import { SeatIcon } from './icons/SeatIcon';

interface Flight {
  id: string;
  airline: string;
  flightNumber: string;
  departure: {
    airport: string;
    city: string;
    time: string;
    date: string;
  };
  arrival: {
    airport: string;
    city: string;
    time: string;
    date: string;
  };
  duration: string;
  price: number;
  currency: string;
  availableSeats: number;
  aircraft: string;
  class: string;
  stops: number;
  isDirect: boolean;
}

interface ModernFlightCardProps {
  flight: Flight;
  onSelect?: (flight: Flight) => void;
  className?: string;
  showDetails?: boolean;
}

const ModernFlightCard: React.FC<ModernFlightCardProps> = ({
  flight,
  onSelect,
  className = '',
  showDetails = true
}) => {
  const { t } = useLocalization();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fa-IR').format(price);
  };

  const formatTime = (time: string) => {
    return new Date(time).toLocaleTimeString('fa-IR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStopsText = () => {
    if (flight.isDirect) return 'مستقیم';
    if (flight.stops === 1) return '۱ توقف';
    return `${flight.stops} توقف`;
  };

  const getStopsColor = () => {
    if (flight.isDirect) return 'text-green-600 bg-green-100';
    return 'text-orange-600 bg-orange-100';
  };

  const handleSelect = () => {
    onSelect?.(flight);
  };

  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow ${className}`}>
      {/* Header */}
      <div className="p-4 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <PlaneIcon className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <div className="font-semibold text-gray-900">{flight.airline}</div>
              <div className="text-sm text-gray-600">{flight.flightNumber}</div>
            </div>
          </div>
          <div className="text-left">
            <div className="text-2xl font-bold text-blue-600">{formatPrice(flight.price)}</div>
            <div className="text-sm text-gray-600">{flight.currency}</div>
          </div>
        </div>
      </div>

      {/* Flight Details */}
      <div className="p-4">
        <div className="flex items-center justify-between">
          {/* Departure */}
          <div className="text-center">
            <div className="text-lg font-semibold text-gray-900">{formatTime(flight.departure.time)}</div>
            <div className="text-sm text-gray-600">{flight.departure.airport}</div>
            <div className="text-xs text-gray-500">{flight.departure.city}</div>
          </div>

          {/* Flight Path */}
          <div className="flex-1 mx-4">
            <div className="flex items-center justify-center">
              <div className="flex-1 h-px bg-gray-300"></div>
              <div className="mx-2">
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStopsColor()}`}>
                  {getStopsText()}
                </div>
                <div className="text-xs text-gray-500 text-center mt-1">{flight.duration}</div>
              </div>
              <div className="flex-1 h-px bg-gray-300"></div>
            </div>
          </div>

          {/* Arrival */}
          <div className="text-center">
            <div className="text-lg font-semibold text-gray-900">{formatTime(flight.arrival.time)}</div>
            <div className="text-sm text-gray-600">{flight.arrival.airport}</div>
            <div className="text-xs text-gray-500">{flight.arrival.city}</div>
          </div>
        </div>
      </div>

      {/* Additional Details */}
      {showDetails && (
        <div className="px-4 pb-4">
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <SeatIcon className="w-4 h-4" />
                <span>{flight.class}</span>
              </div>
              <div className="flex items-center space-x-1">
                <ClockIcon className="w-4 h-4" />
                <span>{flight.aircraft}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-gray-500">
                {flight.availableSeats} صندلی باقی‌مانده
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Action Button */}
      <div className="px-4 pb-4">
        <button
          onClick={handleSelect}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          انتخاب پرواز
        </button>
      </div>
    </div>
  );
};

export default ModernFlightCard;

