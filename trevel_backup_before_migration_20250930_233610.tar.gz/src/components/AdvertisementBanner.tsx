import React, { useState, useEffect } from 'react';
import { useLocalization } from '@/hooks/useLocalization';
import { apiService } from '@/services/apiService';
import { XIcon } from './icons/XIcon';

interface Advertisement {
  id: string;
  title: string;
  description?: string;
  imageUrl: string;
  linkUrl?: string;
  backgroundColor?: string;
  textColor?: string;
  position: string;
  priority: number;
  isActive: boolean;
}

interface AdvertisementBannerProps {
  position?: string;
  className?: string;
  showCloseButton?: boolean;
  autoClose?: boolean;
  autoCloseDelay?: number;
}

const AdvertisementBanner: React.FC<AdvertisementBannerProps> = ({
  position = 'homepage',
  className = '',
  showCloseButton = true,
  autoClose = false,
  autoCloseDelay = 10000
}) => {
  const { t } = useLocalization();
  const [advertisement, setAdvertisement] = useState<Advertisement | null>(null);
  const [isVisible, setIsVisible] = useState(true);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchAdvertisement();
  }, [position]);

  useEffect(() => {
    if (autoClose && advertisement) {
      const timer = setTimeout(() => {
        setIsVisible(false);
      }, autoCloseDelay);
      return () => clearTimeout(timer);
    }
  }, [advertisement, autoClose, autoCloseDelay]);

  const fetchAdvertisement = async () => {
    try {
      setIsLoading(true);
      const response = await apiService.get(`/api/v1/advertisements?position=${position}&isActive=true`);
      const ads = response || [];
      
      if (ads.length > 0) {
        // Sort by priority and get the highest priority ad
        const sortedAds = ads.sort((a: Advertisement, b: Advertisement) => b.priority - a.priority);
        setAdvertisement(sortedAds[0]);
      }
    } catch (error) {
      console.error('Error fetching advertisement:', error);
      // Mock data for demonstration
      setAdvertisement({
        id: '1',
        title: 'پروازهای ارزان به مشهد',
        description: 'بهترین قیمت‌ها برای سفر به مشهد',
        imageUrl: '/images/ads/mashhad-ad.jpg',
        linkUrl: '/flights?to=mashhad',
        backgroundColor: '#f0f9ff',
        textColor: '#1e40af',
        position: position,
        priority: 1,
        isActive: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  const handleClick = () => {
    if (advertisement?.linkUrl) {
      window.open(advertisement.linkUrl, '_blank');
    }
  };

  if (isLoading || !advertisement || !isVisible) {
    return null;
  }

  return (
    <div className={`relative ${className}`}>
      <div
        className="relative rounded-lg overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
        style={{
          backgroundColor: advertisement.backgroundColor || '#ffffff',
          color: advertisement.textColor || '#000000'
        }}
        onClick={handleClick}
      >
        {/* Close Button */}
        {showCloseButton && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleClose();
            }}
            className="absolute top-2 left-2 z-10 w-6 h-6 bg-black bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-colors"
          >
            <XIcon className="w-4 h-4 text-white" />
          </button>
        )}

        {/* Advertisement Content */}
        <div className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h3 className="text-lg font-semibold mb-2">{advertisement.title}</h3>
              {advertisement.description && (
                <p className="text-sm opacity-90">{advertisement.description}</p>
              )}
            </div>
            
            {/* CTA Button */}
            {advertisement.linkUrl && (
              <div className="mr-4">
                <button
                  className="px-4 py-2 bg-white bg-opacity-20 rounded-lg hover:bg-opacity-30 transition-colors font-medium"
                  onClick={(e) => {
                    e.stopPropagation();
                    window.open(advertisement.linkUrl, '_blank');
                  }}
                >
                  مشاهده بیشتر
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Background Image */}
        {advertisement.imageUrl && (
          <div
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{ backgroundImage: `url(${advertisement.imageUrl})` }}
          ></div>
        )}
      </div>
    </div>
  );
};

export default AdvertisementBanner;

