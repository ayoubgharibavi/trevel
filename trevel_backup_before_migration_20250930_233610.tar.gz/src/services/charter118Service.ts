import { apiService } from './apiService';

export interface Charter118FlightSearchRequest {
  origin: string;
  destination: string;
  departureDate: string;
  returnDate?: string;
  adults: number;
  children?: number;
  infants?: number;
  cabinClass?: string;
}

export interface Charter118BookingRequest {
  flightId: string;
  passengers: {
    adults: any[];
    children?: any[];
    infants?: any[];
  };
  contactInfo: {
    email: string;
    phone: string;
    firstName: string;
    lastName: string;
  };
}

export interface Charter118Response<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

class Charter118Service {
  private baseUrl = '/api/v1/charter118';

  /**
   * جستجوی پروازها در Charter118
   */
  async searchFlights(searchRequest: Charter118FlightSearchRequest): Promise<Charter118Response> {
    try {
      const response = await apiService.request(`${this.baseUrl}/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(searchRequest),
      });

      return response;
    } catch (error) {
      console.error('Charter118 search error:', error);
      return {
        success: false,
        error: error.message || 'خطا در جستجوی پروازها',
        message: 'Unable to search flights'
      };
    }
  }

  /**
   * دریافت جزئیات پرواز
   */
  async getFlightDetails(flightId: string): Promise<Charter118Response> {
    try {
      const response = await apiService.request(`${this.baseUrl}/flight/${flightId}`, {
        method: 'GET',
      });

      return response;
    } catch (error) {
      console.error('Charter118 get flight details error:', error);
      return {
        success: false,
        error: error.message || 'خطا در دریافت جزئیات پرواز',
        message: 'Unable to get flight details'
      };
    }
  }

  /**
   * رزرو پرواز
   */
  async bookFlight(bookingRequest: Charter118BookingRequest): Promise<Charter118Response> {
    try {
      const response = await apiService.request(`${this.baseUrl}/book`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(bookingRequest),
      });

      return response;
    } catch (error) {
      console.error('Charter118 booking error:', error);
      return {
        success: false,
        error: error.message || 'خطا در رزرو پرواز',
        message: 'Unable to complete booking'
      };
    }
  }

  /**
   * دریافت وضعیت رزرو
   */
  async getBookingStatus(bookingId: string): Promise<Charter118Response> {
    try {
      const response = await apiService.request(`${this.baseUrl}/booking/${bookingId}`, {
        method: 'GET',
      });

      return response;
    } catch (error) {
      console.error('Charter118 get booking status error:', error);
      return {
        success: false,
        error: error.message || 'خطا در دریافت وضعیت رزرو',
        message: 'Unable to get booking status'
      };
    }
  }

  /**
   * لغو رزرو
   */
  async cancelBooking(bookingId: string): Promise<Charter118Response> {
    try {
      const response = await apiService.request(`${this.baseUrl}/booking/${bookingId}`, {
        method: 'DELETE',
      });

      return response;
    } catch (error) {
      console.error('Charter118 cancel booking error:', error);
      return {
        success: false,
        error: error.message || 'خطا در لغو رزرو',
        message: 'Unable to cancel booking'
      };
    }
  }

  /**
   * دریافت لیست فرودگاه‌ها
   */
  async getAirports(): Promise<Charter118Response> {
    try {
      const response = await apiService.request(`${this.baseUrl}/airports`, {
        method: 'GET',
      });

      return response;
    } catch (error) {
      console.error('Charter118 get airports error:', error);
      return {
        success: false,
        error: error.message || 'خطا در دریافت لیست فرودگاه‌ها',
        message: 'Unable to fetch airports list'
      };
    }
  }

  /**
   * دریافت لیست ایرلاین‌ها
   */
  async getAirlines(): Promise<Charter118Response> {
    try {
      const response = await apiService.request(`${this.baseUrl}/airlines`, {
        method: 'GET',
      });

      return response;
    } catch (error) {
      console.error('Charter118 get airlines error:', error);
      return {
        success: false,
        error: error.message || 'خطا در دریافت لیست ایرلاین‌ها',
        message: 'Unable to fetch airlines list'
      };
    }
  }

  /**
   * تست اتصال به API
   */
  async testConnection(): Promise<Charter118Response> {
    try {
      const response = await apiService.request(`${this.baseUrl}/test-connection`, {
        method: 'GET',
      });

      return response;
    } catch (error) {
      console.error('Charter118 connection test error:', error);
      return {
        success: false,
        error: error.message || 'خطا در تست اتصال',
        message: 'Unable to test connection'
      };
    }
  }

  /**
   * بررسی وضعیت API
   */
  async healthCheck(): Promise<Charter118Response> {
    try {
      const response = await apiService.request(`${this.baseUrl}/health`, {
        method: 'GET',
      });

      return response;
    } catch (error) {
      console.error('Charter118 health check error:', error);
      return {
        success: false,
        error: error.message || 'خطا در بررسی وضعیت',
        message: 'Unable to check health status'
      };
    }
  }
}

export const charter118Service = new Charter118Service();
