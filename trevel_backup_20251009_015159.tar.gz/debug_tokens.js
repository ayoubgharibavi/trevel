console.log('Access Token:', localStorage.getItem('accessToken')); console.log('Current User:', localStorage.getItem('currentUser'));
