import React from 'react';
import { useLocalization } from '@/hooks/useLocalization';

interface SortTabsProps {
  activeSort: string;
  onSortChange: (sort: string) => void;
}

export const SortTabs: React.FC<SortTabsProps> = ({
  activeSort,
  onSortChange
}) => {
  const { language } = useLocalization();
  
  const sortOptions = [
    { id: 'cheapest', label: language === 'en' ? 'Cheapest' : 'ارزان‌ترین' },
    { id: 'fastest', label: language === 'en' ? 'Fastest' : 'سریع‌ترین' },
    { id: 'sort', label: language === 'en' ? 'Sort' : 'مرتب‌سازی' },
    { id: 'other', label: language === 'en' ? 'Others' : 'سایر' }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mb-6" dir={language === 'en' ? 'ltr' : 'rtl'}>
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-4">
          {sortOptions.map((option) => (
            <button
              key={option.id}
              onClick={() => {
                console.log('🔄 Sort button clicked:', option.id);
                onSortChange(option.id);
              }}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeSort === option.id 
                  ? 'bg-blue-600 text-white' 
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>
        <div className="text-sm text-gray-500">
          {language === 'en' ? 'Prices and baggage allowance are for one adult.' : 'قیمت‌ها و بار چمدان برای یک بزرگسال می‌باشد.'}
        </div>
      </div>
    </div>
  );
};
