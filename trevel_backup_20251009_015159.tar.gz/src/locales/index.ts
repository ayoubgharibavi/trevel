import { ar } from './ar';
import { fa } from './fa';
import { en } from './en';

export const translations = {
    ar,
    fa,
    en,
};